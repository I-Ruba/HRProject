import { TypeOf, z } from "zod";

export const RegisterSchema = z.object({
  body: z.object({
    username: z
      .string({
        required_error: "Username is required",
        invalid_type_error: "Username must be a string",
      })
      .min(4, "username must be 4 character")
      .max(15, "username ,must be less 15 character"),
      password: z.string({ required_error: "Password is required" }),
      email: z
      .string({
        required_error: "Email is required",
        invalid_type_error: "plasee enter a email",
      })
      .email(),
  }),
});

export const LoginSchema = z.object({
  body: z.object({
    username: z.string({
      required_error: "Username is required",
      invalid_type_error: "Username must be a string",
    }),
    password: z.string({
      required_error: "Password is required",
      invalid_type_error: "Password must be a string",
    }),
  }),
});

export type RegistertypeSchema = TypeOf<typeof RegisterSchema>["body"];
export type LogintypeSchema = TypeOf<typeof LoginSchema>["body"];
