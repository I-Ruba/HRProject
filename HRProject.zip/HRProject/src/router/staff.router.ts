import express from "express";
import { addStaff, updeteStaff, GetStaffwithId, DeleteStaff } from "../controller/staff.control";

const router = express.Router();

router.post('/addstaff',addStaff)
router.put('/updeteStaff/:id',updeteStaff)
router.get('/GetStaffwithId/:id',GetStaffwithId)
router.delete('/DeleteStaff/:id',DeleteStaff)


export default router;
