import express from "express";
import { connectDB } from "./config/db";
import authRouter from "././router/auth.router";
import staffRouter from "././router/staff.router";

const app = express();
const PORT = 5000;
app.use(express.json());
connectDB();
app.use("/api/hradmin", authRouter);
app.use("/api/staff", staffRouter);

app.listen(PORT, () => {
  console.log("server listening on port " + PORT);
});
