import { Staff } from "@prisma/client";
import { Request, Response } from "express";
import { prisma } from "../config/db";

export const addStaff = async (req: Request, res: Response) => {
  try {
    const newStaff = req.body as Staff;
    await prisma.staff.create({
      data: newStaff,
    });
    res.status(201).json({
      message: " Staff Added",
    });
  } catch (error) {
    console.log(error);
  }
};

export const updeteStaff = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const updeteBlog = req.body as Staff;
    await prisma.staff.update({
      where: { id },
      data: updeteBlog,
    });
    res.status(200).json({
      message: " Staff Updated",
    });
  } catch (error) {
    console.log(error);
  }
};


export const GetStaffwithId = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const staff = await prisma.staff.findMany({
      where: { user_id: id },
      select: {
        id: true,
        name:true,
        degree:true,
        role:true,
        Salary:true,
        HR_Admin: {
          select: {
            id: true,
            username: true,
            email: true,
          },
        },
      },
    });

    if (staff.length == 0) {
      return res.status(400).json({
        // message: "This user doesn't have any blogs",
        message: "This user doesn't have any staff",
      });
    }
    res.status(200).json(staff);
  } catch (error) {
    console.log(error);
  }
};

export const DeleteStaff = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    await prisma.staff.delete({
      where: { id },
    });

    res.status(200).json({
      message: "Staff Deleted",
    });
  } catch (error) {
    console.log(error);
  }
};
